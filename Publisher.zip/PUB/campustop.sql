-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 16, 2016 at 07:23 AM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cspublis_campustop`
--
CREATE DATABASE IF NOT EXISTS `cspublis_campustop` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `cspublis_campustop`;

-- --------------------------------------------------------

--
-- Table structure for table `biographys`
--

CREATE TABLE IF NOT EXISTS `biographys` (
  `biography_id` int(10) NOT NULL AUTO_INCREMENT,
  `b_title` varchar(500) NOT NULL,
  `b_description` varchar(500) NOT NULL,
  `b_video_url` varchar(500) NOT NULL,
  `created_dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified_dt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`biography_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `biographys`
--

INSERT INTO `biographys` (`biography_id`, `b_title`, `b_description`, `b_video_url`, `created_dt`, `modified_dt`) VALUES
(1, 'dff', '', '', '2015-12-03 10:02:56', '2015-12-03 10:02:50'),
(5, '', '', 'http://localhost/cak', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, '', '', 'http://localhost/cak', '2015-12-01 06:05:09', '0000-00-00 00:00:00'),
(10, 'a', 'a', '', '2015-12-03 11:38:40', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE IF NOT EXISTS `city` (
  `city_id` int(10) NOT NULL AUTO_INCREMENT,
  `city_name` varchar(50) NOT NULL,
  `province_id` int(10) NOT NULL,
  `country_id` int(10) NOT NULL,
  `status` tinyint(11) NOT NULL,
  `created_dt` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `modified_dt` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`city_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`city_id`, `city_name`, `province_id`, `country_id`, `status`, `created_dt`, `modified_dt`) VALUES
(1, 'baroda', 3, 0, 0, '2015-11-24 07:31:20', '0000-00-00 00:00:00'),
(2, 'ahmedabad11', 3, 0, 1, '2015-11-24 08:55:07', '2015-11-24 08:54:32'),
(6, 'surat', 3, 0, 1, '2015-11-24 08:46:48', '0000-00-00 00:00:00'),
(8, 'test1', 3, 0, 0, '2015-11-24 08:52:10', '2015-11-24 08:56:23'),
(9, 'gandhinagar', 3, 0, 1, '2015-11-24 09:02:09', '2015-11-24 09:02:44'),
(10, 'rajkot', 3, 0, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(13, 'bhavnagar', 3, 0, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(14, 'surat11', 3, 0, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(16, 'ahmedabad', 3, 0, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(17, 'ahmedabad3', 3, 0, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `cms`
--

CREATE TABLE IF NOT EXISTS `cms` (
  `cms_id` int(11) NOT NULL AUTO_INCREMENT,
  `cms_title` varchar(250) DEFAULT NULL,
  `cms_desc` text,
  `created_dt` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `modified_dt` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`cms_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `cms`
--

INSERT INTO `cms` (`cms_id`, `cms_title`, `cms_desc`, `created_dt`, `modified_dt`) VALUES
(1, 'privacy policy', '<p>This Privacy Policy governs the manner in which Campustop collects, uses, maintains and discloses information collected from users (each, a "User") of the campustop.in website ("Site"). This privacy policy applies to the Site and all products and services offered by Campustop.</p><br/>\r\n<h3>Personal Identification Information</h3>\r\n\r\n<p>We may collect personal identification information from Users in a variety of ways, including, but not limited to, when Users visit our site, register on the site, and in connection with other activities, services, features or resources we make available on our Site. Users may be asked for, as appropriate, name, email address, phone number. Users may, however, visit our Site anonymously. We will collect personal identification information from Users only if they voluntarily submit such information to us. Users can always refuse to supply personally identification information, except that it may prevent them from engaging in certain Site related activities.</p><br/>\r\n<h3>Non-Personal Identification Information</h3>\r\n\r\n<p>We may collect non-personal identification information about Users whenever they interact with our Site. Non-personal identification information may include the browser name, the type of computer and technical information about Users means of connection to our Site, such as the operating system and the Internet service providers utilized and other similar information.\r\n</p><br/>\r\n<h3>Web Browser Cookies.</h3>\r\n\r\n<p>Our Site may use "cookies" to enhance User experience. User''s web browser places cookies on their hard drive for record-keeping purposes and sometimes to track information about them. User may choose to set their web browser to refuse cookies, or to alert you when cookies are being sent. If they do so, note that some parts of the Site may not function properly.</p><br/>\r\n<h3>How we use collected information</h3>\r\n\r\n<p>Campustop may collect and use Users personal information for the following purposes:</p>\r\n<ul style="margin-left:5%">\r\n    <li class="b">To improve customer service</li>\r\n    <li class="b">To personalize user experience</li>\r\n    <li class="b">To improve our Site</li>\r\n    <li class="b">To process payments</li>\r\n    <li class="b">To run a promotion, contest, survey or other Site features</li>\r\n    <li class="b">To send periodic emails</li>\r\n    </ul>\r\n\r\n<h3>How we protect your information</h3>\r\n<p>We adopt appropriate data collection, storage and processing practices and security measures to protect against unauthorized access, alteration, disclosure or destruction of your personal information, username, password, transaction information and data stored on our Site.</p>\r\n<h3>Sharing your personal information</h3>\r\n\r\n<p>We do not sell, trade, or rent Users personal identification information to others. We may share generic aggregated demographic information not linked to any personal identification information regarding visitors and users with our business partners, trusted affiliates and advertisers for the purposes outlined above.</p>\r\n<h3>Third Party Websites</h3>\r\n\r\n<p>Users may find advertising or other content on our Site that link to the sites and services of our partners, suppliers, advertisers, sponsors, licensors and other third parties. We do not control the content or links that appear on these sites and are not responsible for the practices employed by websites linked to or from our Site. In addition, these sites or services, including their content and links, may be constantly changing. These sites and services may have their own privacy policies and customer service policies. Browsing and interaction on any other website, including websites which have a link to our Site, is subject to that website''s own terms and policies.</p>\r\n\r\n<h3>Advertising</h3>\r\n<p>Ads appearing on our site may be delivered to Users by advertising partners, who may set cookies. These cookies allow the ad server to recognize your computer each time they send you an online advertisement to compile non personal identification information about you or others who use your computer. This information allows ad networks to, among other things, deliver targeted advertisements that they believe will be of most interest to you. This privacy policy does not cover the use of cookies by any advertisers.</p>\r\n<h3>Changes to this Privacy Policy</h3>\r\n\r\n<p>Campustop has the discretion to update this privacy policy at any time. When we do, we will revise the updated date at the bottom of this page. We encourage Users to frequently check this page for any changes to stay informed about how we are helping to protect the personal information we collect. You acknowledge and agree that it is your responsibility to review this privacy policy periodically and become aware of modifications.</p>\r\n<h3>Your acceptance of these terms</h3>\r\n\r\n<p>By using this Site, you signify your acceptance of this policy. If you do not agree to this policy, please do not use our Site. Your continued use of the Site following the posting of changes to this policy will be deemed your acceptance of those changes.</p>\r\n<h3>Contacting Us</h3>\r\n\r\n<p>If you have any questions about this Privacy Policy, the practices of this site, or your dealings with this site, please contact us at: akash.agl92@gmail.com</p>', '0000-00-00 00:00:00', '2015-11-30 10:20:23'),
(2, 'about us', '<p><em><strong>hello1</strong></em></p>\r\n\r\n<p>how are you1?11</p>\r\n', '0000-00-00 00:00:00', '2015-12-21 06:35:17'),
(5, 'How it Works', '<p>How it Works</p>\r\n', '2015-11-24 09:16:48', '0000-00-00 00:00:00'),
(6, 'Terms of use', '<p>By virtue of registering and using the services provided by the CampuStop.in, you hereby agree to the following usage agreement ("Visitor Agreement"). CampuStop.in may amend this Visitor Agreement by posting an amended version on the Terms & Conditions tab of the CampuStop.in web site. By continuing to use the services, you agree to the Terms & Conditions then posted..</p><br/>\r\n<h3>Rules for Registration</h3>\r\n\r\n<p>You must register to use services provided by the CampuStop.in. As part of the registration process, you will select a password. You agree that the information you supply during that registration process will be accurate and complete and that you will not register under the name of another person. You will not disclose your password to any third party. You will be responsible for preserving the confidentiality of your password. You will notify us of any known or suspected unauthorized use of your account.</p><br/>\r\n<h3>Posted Content</h3>\r\n\r\n<p>Responsibility for what is posted on the website lies with each user--you alone are responsible for the content of your messages, and the consequences of any such messages. You agree not to use our sites to send or submit materials:\r\n</p><br/>\r\n<ul style="margin-left:5%" >\r\n    <li class="b">that are false, inaccurate or misleading.</li>\r\n    <li class="b">that infringe any third party''s copyright, patent, trademark, trade secret or other proprietary rights or rights of publicity or privacy</li>\r\n    <li class="b" >that violate any law, statute, ordinance or regulation (including without limitation those governing export control, consumer protection, unfair competition, anti-discrimination and false advertising)</li>\r\n    <li  class="b">that are libelous, threatening or harassing</li>\r\n    <li>that are obscene or contain any kind of pornography</li>\r\n    <li>that contain any viruses, Trojan horses, worms, time bombs, cancelbots or other computer programming routines that are intended to damage, detrimentally interfere with, surreptitiously intercept or expropriate any system, data or personal information</li>\r\n     <li class="b">that might create liability for us or might cause us to lose (in whole or in part) the services of our Internet service providers or other suppliers</li>\r\n     <li class="b">that interfere with the ability of others to enjoy our site</li>\r\n     <li class="b">that impersonate any other person or entity, whether actual or fictitious, including impersonating an employee or consultant of CampuStop.in</li>\r\n     <li class="b">that link to or include descriptions of goods or services that: (i) are prohibited under this Agreement; or (ii) you do not have a right to link to or include</li>\r\n     <li class="b">that contain any content that you do not have the right to make available under any law or any contractual or fiduciary relationship (such as inside information and confidential information learned under a non-disclosure agreement) or </li>\r\n     <li class="b">that instigate or encourage others to commit illegal activities or cause injury or property damage to any person.</li>\r\n    </ul>\r\n\r\n    <p>We neither endorse nor guarantee the accuracy or propriety of the information users submit. We do, however, reserve the right, but do not assume the obligation, to restrict or prohibit your use of the website if we believe you are violating any of the terms of this Visitor Agreement and to remove, edit, or relocate any submission as we see fit, whether for legal or other reasons.</p>\r\n\r\n    <p>Users may share their email information in our discussion areas. Accordingly, you may not use any other user''s information, personal or otherwise, for any commercial purpose, to send chain letters, junk mail, "spam," or other bulk communications or for developing lists. Any such use by you will be a violation of this Visitor Agreement.</p>\r\n\r\n<h3>Rights</h3>\r\n<p>You acknowledge that:</p>\r\n\r\n<ul style="margin-left:5%">\r\n<li style="list-style-type: square;">We permit access to content that is protected by copyrights, trademarks and other intellectual and proprietary rights and.</li>\r\n<li style="list-style-type: square;">This Visitor Agreement and applicable copyright, trademark and other laws govern your use of such content.</li>\r\n    </ul>\r\n\r\n<h3>Privacy</h3>\r\n\r\n<p>Use of the CampuStop.in services is also governed by our Privacy Policy, which is incorporated into Privacy Policy section of our website.</p>\r\n<h3>Links</h3>\r\n\r\n<p>We welcome links to our website. Hypertext links are allowed as long as the link does not state or imply any sponsorship or endorsement of your site or use a logo without written consent. During the event we may offer links to third-party websites. We are not responsible for those websites or the parties that control them. We are not liable for the content, quality, suitability, functionality or legality of any such sites. You hereby waive any claim you might have against us with respect to such sites and their operators. Services or merchandise ordered through these links are not affiliated with us. All matters concerning such merchandise and services are solely between you and the merchants with whom you do business.</p>\r\n\r\n<h3>Disputes</h3>\r\n<p>You are solely responsible for your interactions with other visitors. CampuStop.in reserves the right, but not the obligation, to monitor disputes between you and other attendees. You may not take legal action against CampuStop.in that results from our website or services provided through the website without first a) sending us, via registered mail or national overnight courier service, a detailed written description of the facts and law out of which your claim arises; and (b) negotiating with us, in good faith, for not less 30 days, toward resolution of the dispute. Any such notice of a dispute must be sent to the address listed on the Contact Us page, and must be received by us within 90 days of a scenario that first gives rise to a dispute. You agree that all legal action relating to this Agreement or any liability of CampuStop.in, relating to the provision or non-provision of services relating to this Agreement or any event will be under the jurisdiction of the laws of India, without regard to any laws relating to conflict of laws, shall apply in resolving any dispute. You agree to submit to the jurisdiction of the courts of India and agree that you will not bring any action against CampuStop.in, in any jurisdiction outside India.</p>\r\n<h3>Discontinuance, Modification & Restrictions</h3>\r\n\r\n<p>We may discontinue, change, suspend, or restrict access to any of our sites or any portion of our sites at any time without liability to you or any third party.</p>\r\n<h3>Liability and Warranties</h3>\r\n\r\n<p>YOU AGREE THAT USE OF THE SITE IS AT YOUR OWN RISK. WE CANNOT AND DO NOT WARRANT THE ACCURACY, COMPLETENESS, CURRENTNESS, NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE OF THE INFORMATION, MATERIALS AND SERVICES AVAILABLE THROUGH THE SITE. WE DO NOT GUARANTEE OUR SITE TO BE ERROR-FREE, SECURE, CONTINUOUSLY AVAILABLE OR FREE OF VIRUSES OR OTHER HARMFUL COMPONENTS. IN NO EVENT SHALL CAMPUSTOP.IN BE LIABLE TO YOU OR ANY THIRD PARTY FOR ANY DAMAGES, INCLUDING, BUT NOT LIMITED TO, CONSEQUENTIAL, SPECIAL, INCIDENTAL, INDIRECT, OR SIMILAR DAMAGES, EVEN IF WE WERE ADVISED BEFOREHAND OF THE POSSIBILITY OF SUCH DAMAGES. YOU AGREE THAT THE LIABILITY OF CAMPUSTOP.IN, IT’S AFFILIATES, AGENTS AND LICENSORS, IF ANY, ARISING OUT OF ANY KIND OF LEGAL CLAIM IN ANY WAY CONNECTED TO CAMPUSTOP.IN WILL NOT EXCEED THE AMOUNT YOU PAID, IF ANY, TO US. BECAUSE SOME STATES DO NOT ALLOW THE EXCLUSION OR LIMITATION OF CERTAIN CATEGORIES OF DAMAGES, THE ABOVE LIMITATION MAY NOT APPLY TO YOU. IN SUCH STATES, THE LIABILITY OF CAMPUSTOP.IN, ITS AFFILIATES, AGENTS AND LICENSORS IS LIMITED TO THE FULLEST EXTENT PERMITTED BY SUCH STATE LAW.</p>\r\n<h3>Sponsor Emails and Opting Out</h3>\r\n\r\n<p>CampuStop.in users can opt-in to receive email notifications directly from CampuStop.in or third party sponsors.</p>', '2015-11-30 07:33:11', '2015-11-30 09:48:01'),
(7, 'faq', '                    <div id="mix-container" class="portfolio-grid">\r\n                                <div class="panel panel-default mix all">\r\n                                    <div class="panel-heading">\r\n                                        <div class="panel-title">\r\n                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">Who is a Learner?</a>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div id="collapse1" class="panel-collapse collapse in">\r\n                                        <div class="panel-body">\r\n                                            <p>Anyone who reads and learns through the materials posted on CampusNotes is referred to as Learner.</p>\r\n                                            \r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                                <div class="panel panel-default mix panel-bg for-learners all">\r\n                                    <div class="panel-heading">\r\n                                        <div class="panel-title">\r\n                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">What is the purpose of Comments in CampusNotes</a>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div id="collapse2" class="panel-collapse collapse">\r\n                                        <div class="panel-body">\r\n                                            <p>If you have any queries related to the corresponding note, then you can post that query in the “Comments” box which will be notified to the educator. The educator, then, may answer to your query in the same comment box of the note as per his/her convenience. Any posts on that note will be notified to you in your mailbox.</p>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                                <div class="panel panel-default mix panel-bg for-learners all">\r\n                                    <div class="panel-heading">\r\n                                        <div class="panel-title">\r\n                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse3">What is the purpose of rating system for notes?</a>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div id="collapse3" class="panel-collapse collapse">\r\n                                        <div class="panel-body">\r\n                                            <p>Students can rate the notes uploaded on portal so that next time when you visit the portal, you need not go through all the notes of your interest rather just view or download the notes with highest rating. This would also save a lot of your time in the 11th hour of exams.</p>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                                 <div class="panel panel-default mix panel-bg for-learners all">\r\n                                    <div class="panel-heading">\r\n                                        <div class="panel-title">\r\n                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse4">What are the benefits that I’ll have using online query resolving privileges?</a>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div id="collapse4" class="panel-collapse collapse">\r\n                                        <div class="panel-body">\r\n                                            <p>There are times when you cannot get your queries resolved for following reasons like:-.</p>\r\n                                            <ol>\r\n                                                <li>Reluctant to ask your queries in the class.</li>\r\n                                                <li>Teacher asking you to come to his/her cabin to resolve your query but he/she is not available most of the time.</li>\r\n                                                <li>Teacher asks you to come later if he is busy or if he is not able to resolve your query on spot.</li>\r\n                                                <li>Your laziness comes in your way to further approach a teacher to get your queries resolved</li>\r\n                                                <li>When you are studying at home/hostel, you have truckloads of queries but you can’t get them cleared immediately or you forget to ask them next day in college.</li>\r\n                                            </ol>\r\n                                            <p>So, these online query resolving features would keep your fundamentals cleared if you keep posting your queries because an educator would have many resources to answer them with various links of video lectures, e-books and other articles or journals.</p>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                                <div class="panel panel-default mix panel-bg for-learners all">\r\n                                    <div class="panel-heading">\r\n                                        <div class="panel-title">\r\n                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse5">How will I be notified if an educator responds to my query?</a>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div id="collapse5" class="panel-collapse collapse">\r\n                                        <div class="panel-body">\r\n                                            <p>You will receive a notification in your registered email address if someone has responded or asked another query on the same query box of that notes.</p>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                                 <div class="panel panel-default mix panel-bg for-learners all">\r\n                                    <div class="panel-heading">\r\n                                        <div class="panel-title">\r\n                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse6">Who is a Learner?</a>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div id="collapse6" class="panel-collapse collapse in">\r\n                                        <div class="panel-body">\r\n                                            <p>Anyone who reads and learns through the materials posted on CampusNotes is referred to as Learner.</p>\r\n                                            \r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                                <div class="panel panel-default mix panel-bg for-educators all">\r\n                                    <div class="panel-heading">\r\n                                        <div class="panel-title">\r\n                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse7">Who are Educators?</a>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div id="collapse7" class="panel-collapse collapse">\r\n                                        <div class="panel-body">\r\n                                            <p>Anyone who uploads notes or share insights about the subjects are referred to as Educators in CampuStop.</p>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                                  <div class="panel panel-default mix panel-bg for-educators all">\r\n                                    <div class="panel-heading">\r\n                                        <div class="panel-title">\r\n                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse8">Who can upload notes?</a>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div id="collapse8" class="panel-collapse collapse">\r\n                                        <div class="panel-body">\r\n                                            <p>Anyone who has actually created the notes and have the copyrights of the notes reserved to him/her. He/She has to create the notes with no plagiarism and must have the ownership of the notes created. It is supposed to be an original creation by the user. If there is any copyright infringement of notes uploaded, we may have to put that note down. You can go visit the terms and conditions to know about the permissible content.</p>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                                <div class="panel panel-default mix panel-bg for-educators all">\r\n                                    <div class="panel-heading">\r\n                                        <div class="panel-title">\r\n                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse9">Why would I upload notes on this portal?</a>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div id="collapse9" class="panel-collapse collapse">\r\n                                        <div class="panel-body">\r\n                                            <p>When you upload notes on this portal, students may ask queries to you directly here. You can resolve their queries at your convenience by finding relevant resources from internet or searching through reference books. You can provide them with links of video lectures, e-books, articles or journals which may be helpful for them to understand the subject. Consequently, the students will fetch better insights about the subject and hence, better marks, with overall better outcome based productivity.</p>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                                <div class="panel panel-default mix panel-bg for-educators all">\r\n                                    <div class="panel-heading">\r\n                                        <div class="panel-title">\r\n                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse10">What’s the benefit for me?</a>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div id="collapse10" class="panel-collapse collapse">\r\n                                        <div class="panel-body">\r\n                                            <p>With the help of this portal you’ll be able to reach out to students in an effective and efficient way beyond the boundaries of your campus. When you are able to connect with the students easily, you will be able to resolve their queries more easily. Moreover, with more number of students wanting you to resolve their queries on your notes would make you popular in the internet also. Since you will be hash-tagged(#) or facebook tagged(@) for more number of times, you will be easily found in Google based on your popularity.</p>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                                <div class="panel panel-default mix panel-bg for-educators all">\r\n                                    <div class="panel-heading">\r\n                                        <div class="panel-title">\r\n                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse10">What is the purpose of “Comments” section?</a>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div id="collapse10" class="panel-collapse collapse">\r\n                                        <div class="panel-body">\r\n                                            <p>The learners/readers can post queries in the comments section and you’ll, thus, be notified by an e-mail about the query asked.</p>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                                <div class="panel panel-default mix panel-bg for-educators all">\r\n                                    <div class="panel-heading">\r\n                                        <div class="panel-title">\r\n                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse11">How do you protect our files from unethical usage?</a>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div id="collapse11" class="panel-collapse collapse">\r\n                                        <div class="panel-body">\r\n                                            <p>:We convert your files automatically to PDF providing the basic security to your files.</p>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                                 <div class="panel panel-default mix panel-bg for-educators all">\r\n                                    <div class="panel-heading">\r\n                                        <div class="panel-title">\r\n                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse12">Is there something that CampuStop want us to do to ensure security from our part?</a>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div id="collapse12" class="panel-collapse collapse">\r\n                                        <div class="panel-body">\r\n                                            <p>:We would really encourage authors to upload materials which have your signature or watermark on every page so that it can prevent unethical usage to a significant extent.</p>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                                <div class="panel panel-default mix panel-bg CampusMarket all">\r\n                                    <div class="panel-heading">\r\n                                        <div class="panel-title">\r\n                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse13">What are the products I can post for sale on CampusMarket?</a>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div id="collapse13" class="panel-collapse collapse">\r\n                                        <div class="panel-body">\r\n                                            <p>You can post any used consumer goods which are in re-usable condition.</p>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                                <div class="panel panel-default mix panel-bg CampusMarket all">\r\n                                    <div class="panel-heading">\r\n                                        <div class="panel-title">\r\n                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse14">Can I sell new products on CampusMarket?</a>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div id="collapse14" class="panel-collapse collapse">\r\n                                        <div class="panel-body">\r\n                                            <p>Yes, you can sell new products here.</p>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                                <div class="panel panel-default mix panel-bg CampusMarket all">\r\n                                    <div class="panel-heading">\r\n                                        <div class="panel-title">\r\n                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse15">Can I use the platform of CampusMarket to start my own online business on-campus?</a>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div id="collapse15" class="panel-collapse collapse">\r\n                                        <div class="panel-body">\r\n                                            <p>Yes, you can start an online business which can be conducted on-campus. But you’ll have to transact offline with your customers, though negotiations and interactions can be done online.</p>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                                 <div class="panel panel-default mix panel-bg CampusMarket all">\r\n                                    <div class="panel-heading">\r\n                                        <div class="panel-title">\r\n                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse16">Do I have to pay any commission to CampusMarket if I sell anything here?</a>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div id="collapse16" class="panel-collapse collapse">\r\n                                        <div class="panel-body">\r\n                                            <p>No, you don’t have to pay any commission to us unless you are selling a new/old product exceeding the quantity of 4, which is considered as an online business.</p>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                                <div class="panel panel-default mix panel-bg CampusMarket all">\r\n                                    <div class="panel-heading">\r\n                                        <div class="panel-title">\r\n                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse17">Why should we sell our used/new consumer products here and not on other platforms like OLX or Quikr ?</a>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div id="collapse17" class="panel-collapse collapse">\r\n                                        <div class="panel-body">\r\n                                            <p>Because if you use CampusMarket, you will not have to incur logistics costs which tend to reduce your net cash inflow. Moreover, making a transaction on campus saves a lot of time for you since you don’t have to fix a meeting in a place at some time committed specifically to this purpose. You can have a rendezvous point on-campus since all your potential buyers report to college everyday just as you do (assuming you go to college everyday) and you won’t have to go all the way to a new location to close the deal. Another advantage is that you are making a deal with one of your campus-mates which assures reliability and confidence of trust to both the parties.</p>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                                <div class="panel panel-default mix panel-bg CampusMarket all">\r\n                                    <div class="panel-heading">\r\n                                        <div class="panel-title">\r\n                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse18">What is the purpose of “Place Bid” field in CampusMarket?</a>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div id="collapse18" class="panel-collapse collapse">\r\n                                        <div class="panel-body">\r\n                                            <p>In “Place Bid”, buyers can quote their price that they are willing to buy the product at. They can bid prices lower/higher than the quoted price of the seller based on their urgency of need. The seller can choose the best buyer among the list of bidders with the highest bid by pressing on “Accept” button against the best buyer’s bid.</p>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                                <div class="panel panel-default mix panel-bg CampusMarket all">\r\n                                    <div class="panel-heading">\r\n                                        <div class="panel-title">\r\n                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse19">Who can see the bids on a product?</a>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div id="collapse19" class="panel-collapse collapse">\r\n                                        <div class="panel-body">\r\n                                            <p>Only the seller can see all the bids on a product from various bidders in “My Ads” tab.</p>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                                 <div class="panel panel-default mix panel-bg CampusMarket all">\r\n                                    <div class="panel-heading">\r\n                                        <div class="panel-title">\r\n                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse20">How do I inform the buyer whom I have planned the product to sell to?</a>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div id="collapse20" class="panel-collapse collapse">\r\n                                        <div class="panel-body">\r\n                                            <p>Click on “Accept” against the buyer’s bid whom you are willing to sell the product to.</p>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                                <div class="panel panel-default mix panel-bg CampusMarket all">\r\n                                    <div class="panel-heading">\r\n                                        <div class="panel-title">\r\n                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse21">What happens when I click on “Accept”?</a>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div id="collapse21" class="panel-collapse collapse">\r\n                                        <div class="panel-body">\r\n                                            <p>As soon as you “Accept” the buyer’s bid, an e-mail is sent to the buyer informing that you are willing to sell the product to him. We presume that you have/will be making the deal with this buyer finally and therefore, we delete your ad from our page immediately after you “Accept” the buyer’s bid.</p>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                                <div class="panel panel-default mix panel-bg CampusMarket all">\r\n                                    <div class="panel-heading">\r\n                                        <div class="panel-title">\r\n                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse22">What is the duration for which my ad stays live on CampusMarket?</a>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div id="collapse22" class="panel-collapse collapse">\r\n                                        <div class="panel-body">\r\n                                            <p>Your ad stays here on CampusMarket until you “Accept” the buyer’s bid or delete the ad yourself.</p>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                                <div class="panel panel-default mix panel-bg CampusMarket all">\r\n                                    <div class="panel-heading">\r\n                                        <div class="panel-title">\r\n                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse23">Can I edit my ad details?</a>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div id="collapse23" class="panel-collapse collapse">\r\n                                        <div class="panel-body">\r\n                                            <p>Yes, you can edit your ad details from “My Ads” tab. Go to My Ads -> Edit Details (of corresponding ad you want to edit).</p>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                                <div class="panel panel-default mix panel-bg CampusMarket all">\r\n                                    <div class="panel-heading">\r\n                                        <div class="panel-title">\r\n                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse24">Can I post more than one picture of the product I am willing to sell?</a>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div id="collapse24" class="panel-collapse collapse">\r\n                                        <div class="panel-body">\r\n                                            <p>No, you cannot. But you can make a collage of various pictures (preferably 3) to showcase your product as much as possible.</p>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                                <div class="panel panel-default mix panel-bg CampusMarket all">\r\n                                    <div class="panel-heading">\r\n                                        <div class="panel-title">\r\n                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse25">What is the purpose of “Comments” section inside the “Ad Details” page?</a>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div id="collapse25" class="panel-collapse collapse">\r\n                                        <div class="panel-body">\r\n                                            <p>You can ask further queries about the product to the seller in order to get more clarifications. Similarly, a seller can post extra info on the comments section for the buyers to know so that he can sell his product faster.</p>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                                  <div class="panel panel-default mix panel-bg CampusMarket all">\r\n                                    <div class="panel-heading">\r\n                                        <div class="panel-title">\r\n                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse26">Can the users of other campuses view my ad and bid on CampusMarket?</a>\r\n                                        </div>\r\n                                    </div>\r\n                                    <div id="collapse26" class="panel-collapse collapse">\r\n                                        <div class="panel-body">\r\n                                            <p>Yes, the users of different campuses can also view the ads posted by you. If they are comfortable making a deal with a non-campus user, they are free to use all the services that CampusMarket provides.</p>\r\n                                        </div>\r\n                                    </div>\r\n                                </div>\r\n                            </div>', '2015-11-30 12:13:31', '2015-11-30 12:15:24');

-- --------------------------------------------------------

--
-- Table structure for table `collage`
--

CREATE TABLE IF NOT EXISTS `collage` (
  `collage_id` int(11) NOT NULL AUTO_INCREMENT,
  `collage_name` varchar(150) NOT NULL,
  `province_id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `status` tinyint(11) NOT NULL,
  `created_dt` timestamp NULL DEFAULT NULL,
  `modified_dt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`collage_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `collage`
--

INSERT INTO `collage` (`collage_id`, `collage_name`, `province_id`, `country_id`, `status`, `created_dt`, `modified_dt`) VALUES
(1, 'Babaria institute of technology', 7, 2, 1, NULL, '2015-11-26 09:14:54'),
(2, 'trst1', 2, 9, 1, NULL, '2015-12-02 09:29:13'),
(3, 'www', 0, 2, 0, '2015-11-24 12:36:09', NULL),
(4, 'dfsff', 0, 2, 0, '2015-11-25 09:46:54', NULL),
(5, 'uu', 1, 2, 1, '2015-11-25 12:28:05', NULL),
(6, 'ww', 7, 2, 1, '2015-11-26 04:32:11', NULL),
(9, 'ss', 7, 2, 1, '2015-11-26 04:37:40', NULL),
(11, 'uuuuuuuuuuu', 2, 9, 1, '2015-12-01 12:05:31', NULL),
(12, 'Babaria institute of technology1', 3, 9, 1, '2015-12-03 12:29:15', NULL),
(13, 'vallabh', 9, 2, 0, '2015-12-04 10:59:45', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `countrys`
--

CREATE TABLE IF NOT EXISTS `countrys` (
  `country_id` int(10) NOT NULL AUTO_INCREMENT,
  `country_name` varchar(100) NOT NULL,
  `country_code` char(4) NOT NULL,
  `status` tinyint(11) NOT NULL,
  `created_dt` timestamp NULL DEFAULT NULL,
  `modified_dt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`country_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `countrys`
--

INSERT INTO `countrys` (`country_id`, `country_name`, `country_code`, `status`, `created_dt`, `modified_dt`) VALUES
(5, 'Canada', 'CA', 0, NULL, '2015-12-04 10:58:38'),
(9, 'india', 'IN', 0, NULL, NULL),
(10, 'usa', 'US', 1, '2015-12-04 10:57:10', '2015-12-05 06:56:49'),
(15, 'australia', 'AUS', 1, '2015-12-05 06:52:53', '2015-12-05 07:16:39');

-- --------------------------------------------------------

--
-- Table structure for table `degree`
--

CREATE TABLE IF NOT EXISTS `degree` (
  `degree_id` int(11) NOT NULL AUTO_INCREMENT,
  `de_name` varchar(250) NOT NULL,
  `de_code` char(10) NOT NULL,
  `status` tinyint(11) NOT NULL,
  `created_dt` timestamp NULL DEFAULT NULL,
  `modified_dt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`degree_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `degree`
--

INSERT INTO `degree` (`degree_id`, `de_name`, `de_code`, `status`, `created_dt`, `modified_dt`) VALUES
(1, 'Computer Enginnering', 'C.E', 1, NULL, '2015-12-04 09:06:41'),
(2, 'Information technology', 'IT', 1, NULL, '2015-12-05 07:02:44'),
(5, 'df', 'DF', 1, NULL, '2015-12-05 07:02:37'),
(6, 'Bechelor of electrical Enginnering', 'BEELECT', 1, '2015-12-05 07:05:29', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `education`
--

CREATE TABLE IF NOT EXISTS `education` (
  `education_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`education_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `newsletter`
--

CREATE TABLE IF NOT EXISTS `newsletter` (
  `newslatter_id` int(11) NOT NULL AUTO_INCREMENT,
  `newslatter_email` varchar(250) NOT NULL,
  `newslatter_status` enum('S','U') NOT NULL DEFAULT 'U' COMMENT 's=subscribe,u=unsubscribe',
  `created_dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified_dt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`newslatter_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `newsletter`
--

INSERT INTO `newsletter` (`newslatter_id`, `newslatter_email`, `newslatter_status`, `created_dt`, `modified_dt`) VALUES
(1, 'admin@computop.in', 'S', '2015-12-04 11:01:47', '0000-00-00 00:00:00'),
(2, 'arachana@gmail.com', 'S', '2015-12-24 04:14:57', '0000-00-00 00:00:00'),
(3, 'rinku@gmail.com', 'S', '2015-12-24 05:27:33', '0000-00-00 00:00:00'),
(4, 'n@gmail.com', 'S', '2015-12-30 07:10:39', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `note`
--

CREATE TABLE IF NOT EXISTS `note` (
  `note_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name_of_resourse` varchar(500) DEFAULT NULL,
  `collage_id` int(11) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `collage_restricted` enum('Y','N') NOT NULL DEFAULT 'N',
  `program_id` int(11) DEFAULT NULL,
  `degree_id` int(11) DEFAULT NULL,
  `tag` text,
  `description_resourse` text,
  `resource_id` int(11) DEFAULT NULL,
  `created_dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified_dt` timestamp NULL DEFAULT NULL,
  `totalprice` float(10,2) DEFAULT NULL,
  PRIMARY KEY (`note_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `note`
--

INSERT INTO `note` (`note_id`, `user_id`, `name_of_resourse`, `collage_id`, `country_id`, `collage_restricted`, `program_id`, `degree_id`, `tag`, `description_resourse`, `resource_id`, `created_dt`, `modified_dt`, `totalprice`) VALUES
(1, 12, 'video', 5, 0, 'N', 4, 5, 'video1', 'videovideovideovideovideovideo', 6, '0000-00-00 00:00:00', NULL, NULL),
(2, 12, 'video', 2, 0, 'N', 5, 2, 'video1', 'video1video1video1video1video1', 5, '0000-00-00 00:00:00', NULL, NULL),
(3, 12, 'sdf', 11, 0, 'N', 4, 5, 'sdf,yy', 'dfsdf', 6, '0000-00-00 00:00:00', NULL, NULL),
(4, 42, 'asd', 2, 0, 'N', 3, 1, 'asd', 'asd', 3, '0000-00-00 00:00:00', NULL, NULL),
(5, 42, 'asd', 1, 0, 'N', 3, 1, 'asd', 'asd', 6, '2015-12-21 08:34:47', '0000-00-00 00:00:00', NULL),
(6, 42, 'asddsdsdsda', 2, 0, 'N', 4, 1, 'asd', 'asd', 6, '2015-12-19 07:26:19', '0000-00-00 00:00:00', NULL),
(7, 42, 'rese2', 9, 0, 'N', 4, 1, 'DE,computer,electronic', 'rese2rese2rese2', 5, '0000-00-00 00:00:00', NULL, NULL),
(8, 42, 'sdf', 2, 0, 'N', 3, 1, 'sdf', 'sdf', 5, '0000-00-00 00:00:00', NULL, NULL),
(9, 42, 'valcheck', 2, 0, 'N', 3, 2, 'dfdf', 'sdfsdf', 5, '0000-00-00 00:00:00', NULL, NULL),
(10, 42, 'validationchekc', 4, 0, 'N', 4, 5, 'hhh', 'fgfgfg', 5, '0000-00-00 00:00:00', NULL, NULL),
(11, 42, 'yyyyyya', 2, 0, 'N', 3, 2, 'yyyyb', 'yyyyyc', 6, '2015-12-19 07:27:29', '0000-00-00 00:00:00', NULL),
(12, 42, 'sd', 2, 0, 'Y', 3, 2, 'sd', 'sd', 5, '0000-00-00 00:00:00', NULL, NULL),
(13, 42, 'video2', 6, 0, 'N', 5, 5, 'df', 'dfdf', 5, '0000-00-00 00:00:00', NULL, NULL),
(14, 42, 'researche', 3, 0, 'N', 2, 6, 're', 'research', 6, '0000-00-00 00:00:00', NULL, NULL),
(15, 42, 'resourse4', 3, 0, 'Y', 4, 5, 'df,jhjhj', 'dfgdfgfdg', 6, '0000-00-00 00:00:00', NULL, NULL),
(16, 42, 'reswewe', 5, 0, 'N', 5, 2, 'wee', 'sdf', 6, '0000-00-00 00:00:00', NULL, NULL),
(17, 42, 'fdf', 3, 9, 'N', 4, 1, 'dfdf', 'dfdfdf', 3, '0000-00-00 00:00:00', NULL, NULL),
(18, 42, 'sdsd', 3, 10, 'N', 3, 2, 'sd', 'sdfsdfsdfsdf', 6, '0000-00-00 00:00:00', NULL, NULL),
(19, 12, 'resourse23cs', 1, 5, 'Y', 3, 1, 'cms,cs2,mm', 'hello resprusecs', 7, '2015-12-22 13:43:17', '0000-00-00 00:00:00', NULL),
(20, 42, 'testresd', 1, 5, 'N', 3, 1, 'test', 'xcvcxv', 6, '0000-00-00 00:00:00', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `note_casestudy_detail`
--

CREATE TABLE IF NOT EXISTS `note_casestudy_detail` (
  `note_casestudy_id` int(11) NOT NULL AUTO_INCREMENT,
  `note_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `field` varchar(250) DEFAULT NULL,
  `created_dt` timestamp NULL DEFAULT NULL,
  `modified_dt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`note_casestudy_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `note_casestudy_detail`
--

INSERT INTO `note_casestudy_detail` (`note_casestudy_id`, `note_id`, `user_id`, `field`, `created_dt`, `modified_dt`) VALUES
(1, 19, 42, 'testingss', '2015-12-20 18:30:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `note_detail`
--

CREATE TABLE IF NOT EXISTS `note_detail` (
  `note_detail_id` int(11) NOT NULL AUTO_INCREMENT,
  `note_id` int(11) DEFAULT NULL,
  `note_casestudy_id` int(11) DEFAULT NULL,
  `note_research_id` int(11) DEFAULT NULL,
  `file_name` varchar(250) DEFAULT NULL,
  `file_price` int(11) DEFAULT NULL,
  `file_price_currancy` varchar(50) DEFAULT NULL,
  `upload_collage_user_flag` enum('Y','N') DEFAULT 'N' COMMENT 'Y=free for your collage users,N=not free',
  `created_dt` timestamp NULL DEFAULT NULL,
  `modified_dt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`note_detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `note_reserchpaper_detail`
--

CREATE TABLE IF NOT EXISTS `note_reserchpaper_detail` (
  `note_research_id` int(11) NOT NULL AUTO_INCREMENT,
  `note_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `field` varchar(250) DEFAULT NULL,
  `read_at` text,
  `publish_in` text,
  `publish_on_month` varchar(250) DEFAULT NULL,
  `publish_on_year` varchar(250) DEFAULT NULL,
  `team_member` text,
  `under_gidance` text,
  `created_dt` timestamp NULL DEFAULT NULL,
  `modified_dt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`note_research_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `note_reserchpaper_detail`
--

INSERT INTO `note_reserchpaper_detail` (`note_research_id`, `note_id`, `user_id`, `field`, `read_at`, `publish_in`, `publish_on_month`, `publish_on_year`, `team_member`, `under_gidance`, `created_dt`, `modified_dt`) VALUES
(1, 1, 12, 'research1', 'pune', 'mumbai', '7', '1993', 'r.r.shah', 'r.r.desai', '0000-00-00 00:00:00', NULL),
(2, 3, 12, 'video1', 'pune', 'mumbai', '5', '1991', 'r.r.shah', 'r.r.desai', '0000-00-00 00:00:00', NULL),
(3, 5, 42, 'asdnn', 'asdnn', 'asdnn', '3', '1990', 'assnn', 'asdnn', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 6, 42, 'sadasdsada', 'sadsadsadb', 'asdsadsadc', '11', '1988', 'sadsadasdd', 'asdasdsade', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(5, 11, 42, 'yyyyyyd', 'yyyyyyye', 'yyyyyyyf', '11', '1992', 'yyyyyg', 'yyyyyyyh', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 14, 42, '', '', '', 'Month', 'Year', '', '', '0000-00-00 00:00:00', NULL),
(7, 15, 42, 'reasearchvalidation', 'reasearchvalidationread', 'reasearchvalidationpuiblic', '11', '1991', 'reasearchvalidationteam', 'reasearchvalidationguide', '0000-00-00 00:00:00', NULL),
(8, 16, 42, 'dfg', 'dfgdsfsdf', 'dfgsdfsdf', '6', '1988', 'fdgsdf', 'dfgsdf', '0000-00-00 00:00:00', NULL),
(9, 18, 42, 'sdf', 'sdf', 'sdf', '3', '1991', 'dsf', 'sdfsdf', '0000-00-00 00:00:00', NULL),
(10, 20, 42, 'testresdw2', 'testresdw2', 'testresdw2', '3', '1987', 'dsdds2', 'sdasdsad', '0000-00-00 00:00:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `note_video_detail`
--

CREATE TABLE IF NOT EXISTS `note_video_detail` (
  `note_video_id` int(11) NOT NULL AUTO_INCREMENT,
  `note_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `youtube_links` text,
  `other_video_links` text,
  `created_dt` timestamp NULL DEFAULT NULL,
  `modified_dt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`note_video_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `note_video_detail`
--

INSERT INTO `note_video_detail` (`note_video_id`, `note_id`, `user_id`, `youtube_links`, `other_video_links`, `created_dt`, `modified_dt`) VALUES
(1, 2, 12, 'https://www.youtube.com/watch?v=tO0RJHbuAJvideo', 'vvvvvvvvv1video1video1', '0000-00-00 00:00:00', NULL),
(2, 7, 42, 'https://www.youtube.com/watch?v=tO0RJHbuAJIttttqss', 'ghghghtttqss', '0000-00-00 00:00:00', NULL),
(3, 8, 42, 'sdfdsf', 'sfdsf', '0000-00-00 00:00:00', NULL),
(4, 9, 42, 'https://www.youtube.com/watch?v=tO0RJHbuAJIdvavd', 'ghghghtttdddd', '0000-00-00 00:00:00', NULL),
(5, 10, 42, 'fgf', 'fgfg', '0000-00-00 00:00:00', NULL),
(6, 12, 42, 'sd', 'sd', '0000-00-00 00:00:00', NULL),
(7, 13, 42, 'https://www.youtube.com/watch?v=tO0RJHbuAJIttttqdf', 'dfghghghtttdf', '0000-00-00 00:00:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `program`
--

CREATE TABLE IF NOT EXISTS `program` (
  `program_id` int(11) NOT NULL AUTO_INCREMENT,
  `pro_name` varchar(250) NOT NULL,
  `pro_code` char(4) NOT NULL,
  `status` tinyint(11) NOT NULL,
  `created_dt` timestamp NULL DEFAULT NULL,
  `modified_dt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`program_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `program`
--

INSERT INTO `program` (`program_id`, `pro_name`, `pro_code`, `status`, `created_dt`, `modified_dt`) VALUES
(2, 'Master  enginneer', 'ME', 1, '2015-12-01 09:27:51', NULL),
(3, 'Bhecholor of engineering', 'B.E', 1, '2015-12-01 10:07:33', '2015-12-03 12:28:34'),
(4, 'MCA', 'MCA', 1, '2015-12-04 11:00:12', NULL),
(5, 'xzc', 'ZXC', 0, '2015-12-05 07:12:29', '2015-12-05 07:15:01');

-- --------------------------------------------------------

--
-- Table structure for table `province`
--

CREATE TABLE IF NOT EXISTS `province` (
  `province_id` int(10) NOT NULL AUTO_INCREMENT,
  `province_name` varchar(50) NOT NULL,
  `country_id` int(10) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created_dt` timestamp NULL DEFAULT NULL,
  `modified_dt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`province_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `province`
--

INSERT INTO `province` (`province_id`, `province_name`, `country_id`, `status`, `created_dt`, `modified_dt`) VALUES
(2, 'maharastra1', 9, 1, NULL, NULL),
(3, 'gujarat', 9, 1, NULL, NULL),
(8, 'rajsthan', 9, 1, NULL, NULL),
(9, 'toranto', 2, 1, NULL, NULL),
(10, 'vbcb', 2, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `publisherprofile`
--

CREATE TABLE IF NOT EXISTS `publisherprofile` (
  `publisherprofile_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `contactname` varchar(500) NOT NULL,
  `companyname` varchar(500) NOT NULL,
  `alternateemail` varchar(500) NOT NULL,
  `contactaddress` varchar(500) NOT NULL,
  `contactext` varchar(500) NOT NULL,
  `contactnumber` varchar(500) NOT NULL,
  `connumberdetail` varchar(500) NOT NULL,
  `faxext` varchar(500) NOT NULL,
  `faxnumber` varchar(500) NOT NULL,
  `skypeid` varchar(500) NOT NULL,
  `displayname` varchar(500) NOT NULL,
  `customurl` varchar(500) NOT NULL,
  `facebookurl` varchar(500) NOT NULL,
  `twitterurl` varchar(500) NOT NULL,
  `linkedInurl` varchar(500) NOT NULL,
  `googleurl` varchar(500) NOT NULL,
  `description` varchar(500) NOT NULL,
  `created_dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified_dt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`publisherprofile_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `publisherprofile`
--

INSERT INTO `publisherprofile` (`publisherprofile_id`, `user_id`, `contactname`, `companyname`, `alternateemail`, `contactaddress`, `contactext`, `contactnumber`, `connumberdetail`, `faxext`, `faxnumber`, `skypeid`, `displayname`, `customurl`, `facebookurl`, `twitterurl`, `linkedInurl`, `googleurl`, `description`, `created_dt`, `modified_dt`) VALUES
(1, 63, 'contact name', 'company name', 'alternate email', 'contact address', '+91', '9033970907`', 'office', '129', '08574123985', 'slxmusaibmansuri', 'Musaib Mansuri', 'custom@campustop.com', 'facebook@campustop.com', 'tweeter@campustop.com', 'linkedin@campustop.com', 'google@campustop.com', 'description......description......description......description......', '2016-01-13 07:09:30', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `publisherprofileorganizationlogo`
--

CREATE TABLE IF NOT EXISTS `publisherprofileorganizationlogo` (
  `organizationlogo_id` int(11) NOT NULL AUTO_INCREMENT,
  `publisherprofile_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `filenameupload` varchar(500) NOT NULL,
  `created_dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `midified_dt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`organizationlogo_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `publisherprofileorganizationlogo`
--

INSERT INTO `publisherprofileorganizationlogo` (`organizationlogo_id`, `publisherprofile_id`, `user_id`, `filenameupload`, `created_dt`, `midified_dt`) VALUES
(1, 1, 63, '1452668955.jpg', '2016-01-13 07:09:30', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `publisher_bookdetail`
--

CREATE TABLE IF NOT EXISTS `publisher_bookdetail` (
  `publisherbook_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(500) NOT NULL,
  `author` varchar(500) NOT NULL,
  `language` varchar(500) NOT NULL,
  `currency` varchar(500) NOT NULL,
  `isbn` varchar(500) NOT NULL,
  `launchdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `numofpages` varchar(500) NOT NULL,
  `keywords` text NOT NULL,
  `description` varchar(500) NOT NULL,
  `resource_type` varchar(500) NOT NULL,
  `devicerestriction` int(11) NOT NULL,
  `uploadebook` varchar(500) NOT NULL,
  `uploadcover` varchar(500) NOT NULL,
  `previewpages` varchar(500) NOT NULL,
  `price` varchar(200) NOT NULL,
  `discountedprice` varchar(100) NOT NULL,
  `created_dt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_dt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publisher_book` varchar(100) NOT NULL,
  PRIMARY KEY (`publisherbook_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=38 ;

--
-- Dumping data for table `publisher_bookdetail`
--

INSERT INTO `publisher_bookdetail` (`publisherbook_id`, `user_id`, `title`, `author`, `language`, `currency`, `isbn`, `launchdate`, `numofpages`, `keywords`, `description`, `resource_type`, `devicerestriction`, `uploadebook`, `uploadcover`, `previewpages`, `price`, `discountedprice`, `created_dt`, `modified_dt`, `publisher_book`) VALUES
(1, 0, '', '', '', 'usd', '', '2016-01-08 12:28:33', '', '', '', '', 0, '', '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', ''),
(2, 63, '', '', '', 'usd', '', '2016-01-08 12:28:33', '', '', '', '', 0, '', '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', ''),
(3, 63, 'ghgfh', 'gfhg', 'gfh', 'usd', 'gfhgf', '2016-01-08 12:28:33', 'gfh', 'gfh', 'g', 'gf', 0, '', '', '', 'ghgf', 'gf', '0000-00-00 00:00:00', '0000-00-00 00:00:00', ''),
(4, 63, 'gfhgf', 'author', 'language', 'inr', 'ISBN', '2016-01-08 12:28:33', 'gf', 'gfh', '', 'hgfh', 0, '', '', '', 'gf', 'gf', '0000-00-00 00:00:00', '0000-00-00 00:00:00', ''),
(5, 63, 'gfhf', 'hgj', 'hgjhg', 'inr', 'ISBN', '2016-01-08 12:28:33', '10', 'gfh', 'gfhgf', 'gfh', 0, '', '', '', 'gfh', 'gf', '0000-00-00 00:00:00', '0000-00-00 00:00:00', ''),
(6, 63, 'Product carousel', 'author', 'fdg', 'inr', 'fd', '2016-01-08 12:28:33', 'fdg', 'fdg', 'fd', 'fd', 0, '', '', '', 'fg', 'fd', '0000-00-00 00:00:00', '0000-00-00 00:00:00', ''),
(7, 63, 'title', 'author', 'language', 'aud', 'ISBN', '2016-01-08 12:28:33', '10', 'key key,k', 'aaaaa', 'pdf', 0, '', '', '', '10.20', '10.20', '0000-00-00 00:00:00', '0000-00-00 00:00:00', ''),
(8, 63, 'title', 'author', 'language', 'usd', 'ISBN', '2016-01-08 12:28:33', '10', 'keyword', 'description', 'pdf', 0, '', '', '', '10.20', '10.20', '0000-00-00 00:00:00', '0000-00-00 00:00:00', ''),
(9, 63, 'title', 'author', 'language', 'usd', 'ISBN', '2016-01-08 12:28:33', 'fdgdf', 'fghgf', 'gfhgfhgf', 'pdf', 0, '', '', '', '10.20', '10.20', '0000-00-00 00:00:00', '0000-00-00 00:00:00', ''),
(10, 63, '', '', '', 'inr', '', '2016-01-08 12:28:33', '', '', '', '', 0, '', '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', ''),
(11, 63, 'title', 'author', 'language', 'cad', '', '2016-01-08 12:28:33', '', '', '', '', 0, '', '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', ''),
(12, 63, '', '', '', 'cad', '', '2016-01-08 12:28:33', '', '', '', '', 0, '', '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', ''),
(13, 63, 'Product carousel', 'fdg', 'fdg', 'cad', 'fdgfd', '2016-01-08 12:28:33', 'fdgdf', 'fdg', 'fdg', 'fd', 0, '', '', '', '10.20', '10.20', '0000-00-00 00:00:00', '0000-00-00 00:00:00', ''),
(14, 63, '', '', '', 'cad', '', '2016-01-08 12:28:33', '', '', '', '', 0, '', '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', ''),
(15, 63, 'gfhgf', '', '', 'cad', '', '2016-01-08 12:28:33', '', '', '', '', 0, '', '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', ''),
(16, 63, '', '', '', 'cad', '', '2016-01-08 12:28:33', '', '', '', '', 0, '', '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', ''),
(17, 63, '', '', '', 'cad', '', '2016-01-08 12:28:33', '', '', '', '', 0, '', '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', ''),
(18, 63, '', '', '', 'inr', '', '2016-01-08 12:28:33', '', '', '', '', 0, '', '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', ''),
(19, 63, 'title', 'author', 'language', 'inr', 'ISBN', '2016-01-08 12:28:33', '10', 'keyword', 'desc', 'pdf', 0, '', '', '', '10.20', '10.20', '0000-00-00 00:00:00', '0000-00-00 00:00:00', ''),
(20, 63, 'title', 'author', 'language', 'eur', '', '2016-01-08 12:28:33', '10', 'k', 'desc', 'pdf', 0, '', '', '', '10.20', '10.20', '0000-00-00 00:00:00', '0000-00-00 00:00:00', ''),
(21, 63, 'Product carousel', 'author', 'language', 'cad', 'ISBN', '2016-01-08 12:28:33', '10', 'KP;', ';LK;KL', 'pdf', 0, '', '', '', '10.20', '10.20', '0000-00-00 00:00:00', '0000-00-00 00:00:00', ''),
(22, 0, 'titlt', 'author', 'lang', 'cad', 'ISBN', '2016-01-08 12:28:33', '34', 'gj', 'fgjgh', 'fghgf', 0, '', '', '', '456', '45', '0000-00-00 00:00:00', '0000-00-00 00:00:00', ''),
(23, 0, 'titlt', 'author', '', 'cad', '', '2016-01-08 12:28:33', '', '', '', '', 0, '', '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', ''),
(24, 0, 'cover', 'author', 'lang', 'cad', 'ISBN', '2016-01-08 12:28:33', '1', 'ab', 'desc', 'pdf', 0, '', '', '', '2', '2', '0000-00-00 00:00:00', '0000-00-00 00:00:00', ''),
(25, 0, 'cover', 'author', '', 'cad', '', '2016-01-08 12:28:33', '', 'fghgf', '', '', 0, '', '', '', '34', '45', '0000-00-00 00:00:00', '0000-00-00 00:00:00', ''),
(26, 0, 'titlt', 'author', '', 'cad', '', '2016-01-08 12:28:33', '', 'fghgf', '', '', 0, '', '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', ''),
(27, 0, 'titlt', 'author', '', 'cad', '', '2016-01-08 12:28:33', '', 'xzc', 'xdsfds', 'ds', 0, '', '', '', '34', '45', '0000-00-00 00:00:00', '0000-00-00 00:00:00', ''),
(28, 0, 'titlt', '', '', 'cad', '', '2016-01-08 12:28:33', '', '', '', '', 0, '', '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', ''),
(29, 0, 'titlt', '', '', 'usd', '', '2016-01-08 12:28:33', '', '', '', 'fghgf', 0, '', '', '', '34', '45', '0000-00-00 00:00:00', '0000-00-00 00:00:00', ''),
(30, 63, 'titlt', 'author', 'lang', 'cad', 'ISBN', '2016-01-08 12:28:33', '34', '', '', 'pdf', 0, '', '', '', '34', '45', '0000-00-00 00:00:00', '0000-00-00 00:00:00', ''),
(31, 63, 'titlt', '', '', 'cad', '', '2016-01-08 12:28:33', '', '', '', '', 0, '', '', '', '34', '45', '0000-00-00 00:00:00', '0000-00-00 00:00:00', ''),
(32, 63, 'titlt', 'author', 'lang', 'cad', 'ISBN', '2016-01-08 12:28:33', '34', 'key', 'desc', 'pdf', 0, '', '', '', '34', '45', '0000-00-00 00:00:00', '0000-00-00 00:00:00', ''),
(33, 63, 'hidden', 'author', 'lang', 'cad', 'ISBN', '2016-01-08 12:29:56', '34', 'dsf', 'fgfd', 'dfh', 0, '', '', '', '34', '45', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'Ebook'),
(34, 63, 'Echapter', 'author', 'lang', 'cad', 'ISBN', '2016-01-09 04:34:04', '34', 'echapter', 'echapter', 'pdf', 0, '', '', '', '2', '2', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'Echapter'),
(35, 63, 'ebook', '', '', 'cad', '', '2016-01-09 04:40:39', '', '', '', '', 0, '', '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'Ebook'),
(36, 63, 'ech', 'author', 'lang', 'cad', 'ISBN', '2016-01-11 09:30:31', '34', 'dfgfdg', 'ffd', '', 0, '', '', '', '25.20', '25.20', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'Echapter'),
(37, 63, 'ghgfhgfh', 'fghgf', 'hfgh', 'cad', '', '2016-01-11 10:07:12', '', '', '', '', 0, '', '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'Echapter');

-- --------------------------------------------------------

--
-- Table structure for table `publisher_previewpagesebook`
--

CREATE TABLE IF NOT EXISTS `publisher_previewpagesebook` (
  `publisher_previewpagesebook_id` int(11) NOT NULL AUTO_INCREMENT,
  `publisherbook_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `filepreviewpage` varchar(500) NOT NULL,
  `created_dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified_dt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`publisher_previewpagesebook_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `publisher_previewpagesebook`
--

INSERT INTO `publisher_previewpagesebook` (`publisher_previewpagesebook_id`, `publisherbook_id`, `user_id`, `filepreviewpage`, `created_dt`, `modified_dt`) VALUES
(1, 31, 63, '1452248588.txt', '2016-01-08 10:23:13', '0000-00-00 00:00:00'),
(2, 32, 63, '1452255757.txt', '2016-01-08 12:22:44', '0000-00-00 00:00:00'),
(3, 33, 63, '1452256182.txt', '2016-01-08 12:29:56', '0000-00-00 00:00:00'),
(4, 34, 63, '1452314029.txt', '2016-01-09 04:34:04', '0000-00-00 00:00:00'),
(5, 36, 63, '1452504619.txt', '2016-01-11 09:30:32', '0000-00-00 00:00:00'),
(6, 37, 63, '1452506830.txt', '2016-01-11 10:07:12', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `publisher_support`
--

CREATE TABLE IF NOT EXISTS `publisher_support` (
  `support_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `issue_description` varchar(500) NOT NULL,
  `name` varchar(500) NOT NULL,
  `alternateemail` varchar(500) NOT NULL,
  `contactext` varchar(500) NOT NULL,
  `contactnumber` varchar(500) NOT NULL,
  `connumberdetail` varchar(500) NOT NULL,
  `created_dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified_dt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`support_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `publisher_support`
--

INSERT INTO `publisher_support` (`support_id`, `user_id`, `issue_description`, `name`, `alternateemail`, `contactext`, `contactnumber`, `connumberdetail`, `created_dt`, `modified_dt`) VALUES
(1, 63, 'Issue Description', 'Support Name', 'musaib.mansuri@gmail.com', '+91', '9033970907', 'home', '2016-01-15 06:10:20', '0000-00-00 00:00:00'),
(2, 63, 'Issue Description', 'Support Name', 'musaib.mansuri@gmail.com', '+91', '9033970907', 'office', '2016-01-15 09:14:53', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `publisher_uploadcoverbook`
--

CREATE TABLE IF NOT EXISTS `publisher_uploadcoverbook` (
  `publisher_uploadcoverbook_id` int(11) NOT NULL AUTO_INCREMENT,
  `publisherbook_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `fileuploadcover` varchar(500) NOT NULL,
  `created_dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified_dt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`publisher_uploadcoverbook_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `publisher_uploadcoverbook`
--

INSERT INTO `publisher_uploadcoverbook` (`publisher_uploadcoverbook_id`, `publisherbook_id`, `user_id`, `fileuploadcover`, `created_dt`, `modified_dt`) VALUES
(1, 29, 63, '1452248096.jpg', '2016-01-08 10:15:02', '0000-00-00 00:00:00'),
(2, 30, 63, '1452248260.jpg', '2016-01-08 10:17:47', '0000-00-00 00:00:00'),
(3, 31, 63, '1452248581.jpg', '2016-01-08 10:23:13', '0000-00-00 00:00:00'),
(4, 32, 63, '1452255752.jpg', '2016-01-08 12:22:44', '0000-00-00 00:00:00'),
(5, 33, 63, '1452256176.jpg', '2016-01-08 12:29:56', '0000-00-00 00:00:00'),
(6, 34, 63, '', '2016-01-09 04:34:04', '0000-00-00 00:00:00'),
(7, 36, 63, '', '2016-01-11 09:30:32', '0000-00-00 00:00:00'),
(8, 37, 63, 'undefined', '2016-01-11 10:07:12', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `publisher_uploadebook`
--

CREATE TABLE IF NOT EXISTS `publisher_uploadebook` (
  `uploadebook_id` int(11) NOT NULL AUTO_INCREMENT,
  `publisherbook_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `filenameupload` varchar(500) NOT NULL,
  `created_dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified_dt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`uploadebook_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `publisher_uploadebook`
--

INSERT INTO `publisher_uploadebook` (`uploadebook_id`, `publisherbook_id`, `user_id`, `filenameupload`, `created_dt`, `modified_dt`) VALUES
(1, 22, 63, '1452243359.txt', '2016-01-08 08:57:03', '0000-00-00 00:00:00'),
(2, 23, 63, '1452244717.txt', '2016-01-08 09:18:42', '0000-00-00 00:00:00'),
(3, 24, 63, '1452245973.txt', '2016-01-08 09:39:52', '0000-00-00 00:00:00'),
(4, 25, 63, '1452246267.txt', '2016-01-08 09:44:45', '0000-00-00 00:00:00'),
(5, 26, 63, '1452247130.txt', '2016-01-08 09:59:08', '0000-00-00 00:00:00'),
(6, 27, 63, '1452247664.txt', '2016-01-08 10:08:03', '0000-00-00 00:00:00'),
(7, 29, 63, '1452248090.txt', '2016-01-08 10:15:02', '0000-00-00 00:00:00'),
(8, 30, 63, '1452248255.txt', '2016-01-08 10:17:46', '0000-00-00 00:00:00'),
(9, 31, 63, '1452248576.txt', '2016-01-08 10:23:13', '0000-00-00 00:00:00'),
(10, 32, 63, '1452255747.txt', '2016-01-08 12:22:44', '0000-00-00 00:00:00'),
(11, 33, 63, '1452256171.txt', '2016-01-08 12:29:56', '0000-00-00 00:00:00'),
(12, 34, 63, '1452314017.txt', '2016-01-09 04:34:04', '0000-00-00 00:00:00'),
(13, 36, 63, '1452504607.txt', '2016-01-11 09:30:32', '0000-00-00 00:00:00'),
(14, 37, 63, '1452506820.txt', '2016-01-11 10:07:12', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `skill`
--

CREATE TABLE IF NOT EXISTS `skill` (
  `skill_id` int(11) NOT NULL AUTO_INCREMENT,
  `skill_title` varchar(200) NOT NULL,
  `created_dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified_dt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`skill_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `skill`
--

INSERT INTO `skill` (`skill_id`, `skill_title`, `created_dt`, `modified_dt`) VALUES
(1, 'C+++', '0000-00-00 00:00:00', '2015-12-01 05:27:45'),
(3, 'C+1', '2015-12-03 10:04:46', '2015-12-03 10:04:44'),
(6, 'd', '2015-12-03 11:52:49', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `social_acount_info`
--

CREATE TABLE IF NOT EXISTS `social_acount_info` (
  `social_acount_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `id` int(50) DEFAULT NULL,
  `profile_link` varchar(250) DEFAULT NULL,
  `gender` varchar(250) DEFAULT NULL,
  `user_name` varchar(250) DEFAULT NULL,
  `profile_image` varchar(250) DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `fname` varchar(250) DEFAULT NULL,
  `lname` varchar(250) DEFAULT NULL,
  `age` text,
  `location` varchar(250) DEFAULT NULL,
  `timezone` varchar(250) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `date_of_birth` varchar(250) DEFAULT NULL,
  `hometown` varchar(250) DEFAULT NULL,
  `city` varchar(250) DEFAULT NULL,
  `m_status` varchar(250) DEFAULT NULL,
  `user_website` varchar(250) DEFAULT NULL,
  `user_occupation` text,
  `skill` text,
  `work_exp` text,
  `varified` varchar(250) DEFAULT NULL,
  `about` text,
  PRIMARY KEY (`social_acount_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `testinomials`
--

CREATE TABLE IF NOT EXISTS `testinomials` (
  `testimonial_id` int(11) NOT NULL AUTO_INCREMENT,
  `t_description` mediumtext NOT NULL,
  `t_rating` float NOT NULL,
  `t_image` varchar(50) NOT NULL,
  `t_name` varchar(50) NOT NULL,
  `t_designation` varchar(50) NOT NULL,
  `t_college` varchar(200) NOT NULL,
  `t_sortorder` int(11) NOT NULL,
  `created_dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified_dt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`testimonial_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `testinomials`
--

INSERT INTO `testinomials` (`testimonial_id`, `t_description`, `t_rating`, `t_image`, `t_name`, `t_designation`, `t_college`, `t_sortorder`, `created_dt`, `modified_dt`) VALUES
(18, 'testtesttesttesttesttesttesttesttesttesttesttesttesttesttesttest', 1, '', '', 'test', 'tedst', 4, '2015-12-24 04:39:47', '2015-12-24 04:39:42'),
(19, 'cv', 2, '', 'mm', 'mm', 'mm', 1, '2015-12-04 09:44:52', '2015-12-04 09:44:48'),
(22, 'cc1', 3, '', 'cc1', 'cc1', 'cc1', 4, '2015-12-04 09:45:02', '2015-12-04 09:44:59'),
(23, 'cc', 4, '', 'ccj', 'cc', 'cc', 4, '2015-12-04 09:45:08', '2015-12-04 09:45:05'),
(24, 'df', 6, '1449468444.jpg', 'df', 'df', 'df', 6, '2015-12-07 06:07:15', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `types_of_resource`
--

CREATE TABLE IF NOT EXISTS `types_of_resource` (
  `resource_id` int(11) NOT NULL AUTO_INCREMENT,
  `resource_name` varchar(150) NOT NULL,
  `created_dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified_dt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` int(11) NOT NULL,
  PRIMARY KEY (`resource_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `types_of_resource`
--

INSERT INTO `types_of_resource` (`resource_id`, `resource_name`, `created_dt`, `modified_dt`, `status`) VALUES
(3, 'Notes', '2015-12-07 01:46:33', '2015-12-07 03:31:11', 0),
(4, 'notes1', '2015-12-07 03:27:21', '0000-00-00 00:00:00', 0),
(5, 'video', '2015-12-12 08:14:30', '0000-00-00 00:00:00', 0),
(6, 'research', '2015-12-17 10:46:18', '0000-00-00 00:00:00', 0),
(7, 'case studay', '2015-12-21 08:12:51', '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `univercity`
--

CREATE TABLE IF NOT EXISTS `univercity` (
  `univercity_id` int(11) NOT NULL AUTO_INCREMENT,
  `univercity_name` varchar(25) NOT NULL,
  `country_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `created_dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified_dt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`univercity_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `univercity`
--

INSERT INTO `univercity` (`univercity_id`, `univercity_name`, `country_id`, `status`, `created_dt`, `modified_dt`) VALUES
(1, 'saurastra1', 2, 1, '2015-12-03 11:20:19', '0000-00-00 00:00:00'),
(2, 'TEB', 5, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 'gujarat1', 2, 1, '2015-12-03 11:20:47', '0000-00-00 00:00:00'),
(4, 'south gujarat', 9, 1, '2015-12-03 11:17:23', '0000-00-00 00:00:00'),
(5, 'saurastra', 9, 1, '2015-12-03 11:20:05', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `userrole`
--

CREATE TABLE IF NOT EXISTS `userrole` (
  `user_role_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_role_name` varchar(150) NOT NULL,
  `user_role_code` varchar(20) NOT NULL,
  `created_dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified_dt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`user_role_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `userrole`
--

INSERT INTO `userrole` (`user_role_id`, `user_role_name`, `user_role_code`, `created_dt`, `modified_dt`) VALUES
(2, 'superadmin', 'S', '2015-12-04 09:47:51', '2015-12-04 09:47:48'),
(3, 'admin', 'a', '2015-12-04 09:48:00', '2015-12-04 09:47:55'),
(4, 'publisher', 'pub', '2016-01-01 11:14:16', '2016-01-01 11:14:05');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fname` varchar(100) NOT NULL,
  `mname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(500) DEFAULT NULL,
  `user_role_name` varchar(20) DEFAULT NULL,
  `created_dt` timestamp NULL DEFAULT NULL,
  `modified_dt` timestamp NULL DEFAULT NULL,
  `status` enum('A','D') NOT NULL,
  `country_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=64 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `fname`, `mname`, `lname`, `username`, `password`, `user_role_name`, `created_dt`, `modified_dt`, `status`, `country_id`) VALUES
(12, 'sdd', 'j', 'shah1', 'admin', '$2y$10$sVwOXvI4DbU8xTNTF2JMxeQx1Ob/gqi1vUeoXL3cuY3NPqVap6IIq', 'admin', NULL, NULL, '', 5),
(37, 'nidhiv4cvv444444', 'v4cvv44444', 'gandhi4cvv444444', 'ranu@mail.com', '$2y$10$AFXl8BYccBShEN3qRyQ5/O8TId1jGv/4GnLzD2msyPdArgdEiT/a.', 'student', NULL, NULL, '', 5),
(38, 'nidhiv', 'v', 'gandhi', 'nidhi@gmail.com', '$2y$10$1NvJ22zSDZ.58kOecRbiq.GaPMLx/0cGsQc4EtGGrppuFvaKu5lRm', 'student', NULL, NULL, '', 5),
(39, 'naiya', 'j', 'shah', 'naiya@gmail.com', '$2y$10$soqbCoUuY0QaY11.goMpJOsqzYgIixYbZJJzvabOzdPKJKTgRqc0q', 'student', NULL, NULL, '', 0),
(40, 'vi', 'v', 'gandhi', 'vi@test.com', '$2y$10$XWLVMtClivio/jAfE21H0Os5s2ejgy/32mQTGM5GzjKXPRWASL/2y', 'student', NULL, NULL, '', 5),
(41, 'madhuri', 'k', 'patel', 'madhuri@gmail.com', '$2y$10$akSai7Erdmvhx7GqFEYc7uFSTCnkhOXnajmmEywdzCuW4gc1WAtUW', 'student', NULL, NULL, '', 9),
(42, 'margi1', 'j', 'fdgdfg1', 'margi@gmail.com', '$2y$10$AFXl8BYccBShEN3qRyQ5/O8TId1jGv/4GnLzD2msyPdArgdEiT/a.', 'student', NULL, NULL, '', 9),
(57, 'arachana1', 'a', 'patel', 'arachana@gmail.com', '$2y$10$6vMFp6RnrHaCRGQytQYQ8OAcH./e8VAr7iFuIA5nyfRCMJJEISBRm', NULL, NULL, NULL, 'A', 5),
(61, 'rinku', 'j', 'shah', 'rinku@gmail.com', '$2y$10$9pCc5KAJpqhugVdss0eGf.YToAsiLkrpk60DUTnqx09gIPAPUj94O', NULL, NULL, NULL, 'A', 9),
(62, 'test', 'test', 'test', 'n@gmail.com', '$2y$10$DaBNXhySBRtZIVkfS5zrcOGf.2VgD.an8hLX6w4VDHYSWBaKJBGbm', NULL, NULL, NULL, 'A', 9),
(63, 'a', 'bbbbb', 'bbbb', 'publisher@publisher.com', '$2y$10$k3b.7sqoqpq3xx/9N.4dMuAw7f/FAZcQBC0VeFka4oXy5RZZnBEI2', 'publisher', NULL, NULL, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_basic`
--

CREATE TABLE IF NOT EXISTS `user_basic` (
  `user_basic_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `email_flag` enum('0','1') NOT NULL DEFAULT '1' COMMENT '0=private,1=public',
  `gender` enum('F','M') DEFAULT 'M',
  `gender_flag` enum('0','1') NOT NULL DEFAULT '1' COMMENT '0=private,1=public',
  `country_id` int(11) DEFAULT NULL,
  `country_flag` enum('0','1') NOT NULL DEFAULT '1' COMMENT '0=private,1=public',
  `contact_number` varchar(100) DEFAULT NULL,
  `contact_flag` enum('0','1') NOT NULL DEFAULT '1' COMMENT '0=private,1=public',
  `province_id` int(11) DEFAULT NULL,
  `province_flag` enum('0','1') NOT NULL DEFAULT '1' COMMENT '0=private,1=public',
  `city_id` int(11) DEFAULT NULL,
  `city_flag` enum('0','1') NOT NULL DEFAULT '1' COMMENT '0=private,1=public',
  `timezone` varchar(100) DEFAULT NULL,
  `timezone_flag` enum('0','1') NOT NULL DEFAULT '1' COMMENT '0=private,1=public',
  `zipcode` int(50) DEFAULT NULL,
  `zipcode_flag` enum('0','1') NOT NULL DEFAULT '1' COMMENT '0=private,1=public',
  `profile_pic` varchar(500) DEFAULT NULL,
  `user_referal_id` varchar(50) DEFAULT NULL,
  `created_dt` timestamp NULL DEFAULT NULL,
  `modified_dt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_basic_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `user_basic`
--

INSERT INTO `user_basic` (`user_basic_id`, `user_id`, `email_flag`, `gender`, `gender_flag`, `country_id`, `country_flag`, `contact_number`, `contact_flag`, `province_id`, `province_flag`, `city_id`, `city_flag`, `timezone`, `timezone_flag`, `zipcode`, `zipcode_flag`, `profile_pic`, `user_referal_id`, `created_dt`, `modified_dt`) VALUES
(1, 0, '1', 'F', '0', 9, '1', '676767', '0', 3, '0', 6, '1', 'UTC?08:00 (PST)', '0', 6767, '0', NULL, NULL, NULL, NULL),
(2, 0, '1', 'F', '0', 9, '1', 'dsdsad', '1', 3, '1', 6, '1', 'UTC?07:00 (MST)', '1', 565656, '1', NULL, NULL, NULL, NULL),
(3, 0, '1', 'F', '0', 9, '1', 'dsdsad', '1', 3, '1', 6, '1', 'UTC?07:00 (MST)', '1', 565656, '1', NULL, NULL, NULL, NULL),
(4, 0, '1', 'F', '0', 9, '1', 'dsdsad', '1', 3, '1', 6, '1', 'UTC?07:00 (MST)', '1', 565656, '1', NULL, NULL, NULL, NULL),
(5, 0, '0', 'F', '1', 9, '1', '34343443', '1', 3, '1', 6, '1', 'UTC?08:00 (PST)', '1', 343434, '0', NULL, NULL, NULL, NULL),
(6, 0, '0', 'F', '0', 9, '0', '123456789', '0', 3, '0', 16, '0', 'UTC?08:00 (PST)', '0', 343434, '0', NULL, NULL, NULL, NULL),
(7, 37, '0', 'F', '0', 9, '0', '2322333333vvvv', '0', 3, '0', 9, '0', 'UTC?08:00 (PST)', '0', 122323, '0', '1449809111.jpg', NULL, NULL, NULL),
(8, 38, '0', 'M', '0', 9, '0', '89898989898', '0', 3, '0', 6, '0', 'UTC?06:00 (CST)', '0', 111111, '0', '1449814545.jpg', NULL, NULL, NULL),
(9, 41, '0', 'F', '0', 9, '0', '76767676', '0', 3, '0', 8, '0', 'UTC?08:00 (PST)', '0', 12232333, '0', '1449819957.jpg', NULL, NULL, NULL),
(10, 12, '0', 'M', '0', 9, '0', '23223333', '0', 3, '0', 14, '0', 'UTC+05:30 (IST)', '0', 2323, '0', NULL, NULL, NULL, NULL),
(11, 42, '0', 'F', '0', 9, '0', '99898989891', '0', 3, '0', 2, '0', 'UTC+05:30 (IST)', '1', 7878781, '1', '1451461087.jpg', NULL, NULL, NULL),
(12, 60, '0', 'M', '0', 9, '0', '9998776655', '0', 3, '0', 1, '0', 'UTC+05:30 (IST)', '0', 39008, '0', NULL, NULL, NULL, NULL),
(13, 61, '0', NULL, '0', 9, '0', '23223333', '0', 3, '0', 2, '0', 'UTC?08:00 (PST)', '0', 56565656, '0', '1451313305.jpg', NULL, NULL, NULL),
(14, 57, '0', 'M', '0', 9, '1', '9978654534', '1', 3, '1', 1, '1', 'UTC+05:30 (IST)', '1', 390088, '1', '1451314758.jpg', NULL, NULL, NULL),
(15, 63, '1', 'M', '1', NULL, '1', NULL, '1', NULL, '1', NULL, '1', NULL, '1', NULL, '1', '1452061575.jpg', NULL, NULL, NULL),
(16, 12, '1', 'M', '1', NULL, '1', NULL, '1', NULL, '1', NULL, '1', NULL, '1', NULL, '1', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_education`
--

CREATE TABLE IF NOT EXISTS `user_education` (
  `user_education_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `program_id` int(11) DEFAULT NULL,
  `major_id` int(11) DEFAULT NULL,
  `course_name` varchar(250) DEFAULT NULL,
  `university_id` int(11) DEFAULT NULL,
  `collage_id` int(11) DEFAULT NULL,
  `starting_year` int(11) DEFAULT NULL,
  `ending_year` int(11) DEFAULT NULL,
  `education_flag` enum('0','1') DEFAULT '1' COMMENT '0=private,1=public',
  `created_dt` timestamp NULL DEFAULT NULL,
  `modified_dt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_education_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `user_education`
--

INSERT INTO `user_education` (`user_education_id`, `user_id`, `program_id`, `major_id`, `course_name`, `university_id`, `collage_id`, `starting_year`, `ending_year`, `education_flag`, `created_dt`, `modified_dt`) VALUES
(1, 12, NULL, NULL, 'dfdf', NULL, NULL, 0, 0, '1', NULL, NULL),
(2, 42, NULL, NULL, 'test,dfdsf,dff dfsdf  dfdf fdgdfg', NULL, NULL, 0, 0, '1', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_skills_interest`
--

CREATE TABLE IF NOT EXISTS `user_skills_interest` (
  `skill_interest_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `hard_skill` text,
  `soft_skill` text,
  `interest` text,
  `created_dt` timestamp NULL DEFAULT NULL,
  `modified_dt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`skill_interest_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `user_work_experiance`
--

CREATE TABLE IF NOT EXISTS `user_work_experiance` (
  `user_work_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `worked_in` varchar(500) DEFAULT NULL,
  `job_was` varchar(500) DEFAULT NULL,
  `worked_on` varchar(500) DEFAULT NULL,
  `work_from` int(11) DEFAULT NULL,
  `work_end` int(11) DEFAULT NULL,
  `current_work_flag` enum('Y','N') NOT NULL DEFAULT 'Y',
  `work_experience` text,
  `created_dt` timestamp NULL DEFAULT NULL,
  `modified_dt` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
